# import sys
# sys.stdin = open('algo2_sample_in.txt')

# 김싸피가 모으는 보석 종류
want = [4, 6, 7, 9, 11]

T = int(input())

for tc in range(1, T+1):
    # 보석 갯수 N, 예산 M
    N, M = map(int, input().split())
    # 보석 가치 리스트
    data = list(map(int, input().split()))

    # 원하는 보석 배수인것만 새로 담기
    new_data = []
    for i in want:
        for j in range(N):
            if data[j] % i == 0:
                new_data.append(data[j])
    new_data.sort()
    # print(new_data)
    # 부분집합 구하고 합 구하기


