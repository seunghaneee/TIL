# import sys
# sys.stdin = open('algo1_sample_in.txt')

# 델타 탐색
dx = [-1, 1, 0 ,0]
dy = [0 ,0, -1, 1]

T = int(input())

for tc in range(1, T+1):
    # 지도의 크기 N
    N = int(input())
    # 지도 정보 arr
    arr = [list(map(int, input().split())) for _ in range(N)]

    for i in range(N):
        for j in range(N):
            if arr[i][j] == 2:
                for idx in range(4):
                    di = i + dx[idx]
                    dj = j + dy[idx]
                    if 0 <= di < N and 0 <= dj < N and arr[di][dj] == 0:
                        arr[di][dj] = 3
                        for _ in range(N):
                            if 0 <= di + dx[idx] < N and 0 <= dj + dy[idx] < N:
                                if arr[di + dx[idx]][dj + dy[idx]] == 0:
                                    arr[di + dx[idx]][dj + dy[idx]] = 3
                                    di = di + dx[idx]
                                    dj = dj + dy[idx]

    for i in range(N):
        for j in range(N):
            for idx in range(4):
                di = i + dx[idx]
                dj = j + dy[idx]
                if 0 <= di < N and 0 <= dj < N and arr[di][dj] == 0:
                    if arr[i][j] == 0 and (arr[di][dj] == 2 or arr[di][dj] == 3):
                        arr[i][j] = 3

    print(arr)
    # 안전구역 확인
    count = 0
    for i in range(N):
        for j in range(N):
            if arr[i][j] == 0:
                count += 1

    print(f'#{tc} {count}')