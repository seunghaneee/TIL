
T = int(input())

for tc in range(1, T+1):
    # 봉우리 개수 N
    N = int(input())
    # 각 봉우리 높이 리스트
    h = list(map(int, input().split()))

    # 각 봉우리 높이가 다른것만 받아올 리스트
    h_stack = []
    # 결과값 (만약 봉우리가 없다면(len(h_stack) == 0) -> result = 0)
    result = 0
    for i in h:
        # 만약 새로운 봉우리 리스트가 비었으면 일단 추가
        if len(h_stack) == 0:
            h_stack.append(i)
        # 앞의 봉우리 높이와 현재 봉우리 높이가 같지 않을때만 추가
        if h_stack[-1] != i:
            h_stack.append(i)
    # print(h_stack)

    # 만약 봉우리가 1개이고 그 높이가 0이 아니라면
    if len(h_stack) == 1 and h_stack[0] != 0:
        # 봉우리 개수는 1개이다.
        result = 1
    # 만약 봉우리의 개수가 2개일 때
    elif len(h_stack) == 2:
        if h_stack[0] != h_stack[1]:
            result = 1
    # 봉우리가 3개 이상일 때
    elif len(h_stack) >= 3:
        # 맨 앞쪽 지형은 다음지형보다 높으면 봉우리이고
        if h_stack[0] > h_stack[1]:
            result += 1
        # 맨 뒤쪽 지형은 이전 지형보다 높으면 봉우리다.
        if h_stack[-1] > h_stack[-2]:
            result += 1
        # 맨 앞과 맨 뒤를 제외한 나머지 부분에서 확인
        # 현재 높이가 양쪽 지형보다 높으면 봉우리다.
        for i in range(1, len(h_stack)-1):
            if h_stack[i] > h_stack[i-1] and h_stack[i] > h_stack[i+1]:
                result += 1

    print(f'#{tc} {result}')